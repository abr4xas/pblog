How to use these files
===

To get your Windows 8.1 tiles up and running on your site, 
upload the browserconfig.xml and PNG files in this ZIP to the root of your website. 
The browserconfig.xml contains references to your logo assets and notifications. No other changes to your webpage are required!
